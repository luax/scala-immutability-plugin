object
MainTest
{
  foo(a, // comment
    b)
}
