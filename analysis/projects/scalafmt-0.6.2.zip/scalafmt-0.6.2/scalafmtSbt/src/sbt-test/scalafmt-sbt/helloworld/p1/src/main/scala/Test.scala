object
Test
{
  foo(a, // comment
    b)
}
