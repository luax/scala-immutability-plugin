package org.scalafmt.util

case class FormatOutput(token: String, whitespace: String, visits: Int)
