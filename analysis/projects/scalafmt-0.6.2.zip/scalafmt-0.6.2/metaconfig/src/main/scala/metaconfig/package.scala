package object metaconfig {
  type Result[T] = Either[Throwable, T]
}
