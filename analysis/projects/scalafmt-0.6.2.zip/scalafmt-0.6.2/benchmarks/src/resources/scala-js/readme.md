These files are taken from [Scala.js](https://github.com/scala-js/scala-js/).
See attached licence.
