object Deps {
  val scalameta = "1.6.0"
  val scalatest = "3.0.1"
  val scalariform = "0.1.8"
  val coursier = "1.0.0-M15-1"
}
