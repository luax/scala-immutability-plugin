/* Scala.js example code
 * Public domain
 * Author: Sébastien Doeraene
 */

$(function() {
  ScalaJS.modules.helloworld_HelloWorld().main();
});
