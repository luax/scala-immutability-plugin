# Scala.js Continuous Integration Jenkins tracking

These files track execution scripts in our Jenkins installation. They
are only here to track changes we make to our Jenkins configuration.

Unlike the files in the parent directory, any CI build should always
run with the configuration corresponding to the files on the master
branch. They specify how to run the tests (exact Jenkins
environment).

The files in the parent directory specify what to run.
