This is the repository for
[Scala.js, the Scala to JavaScript compiler](http://www.scala-js.org/).

* [Report an issue](https://github.com/scala-js/scala-js/issues)
* [Developer documentation](./DEVELOPING.md)
* [Contributing guidelines](./CONTRIBUTING.md)

## License

Scala.js is distributed under the
[Scala License](http://www.scala-lang.org/license.html).
