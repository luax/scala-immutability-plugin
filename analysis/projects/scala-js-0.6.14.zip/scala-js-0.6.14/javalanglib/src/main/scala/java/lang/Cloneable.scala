package java.lang

trait Cloneable
