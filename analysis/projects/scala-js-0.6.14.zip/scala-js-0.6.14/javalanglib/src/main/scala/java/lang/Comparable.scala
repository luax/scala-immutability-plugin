package java.lang

trait Comparable[A] {
  def compareTo(o: A): scala.Int
}
