package java.lang

trait Runnable {
  def run(): Unit
}
