package java.nio.charset

class CoderMalfunctionError(cause: Exception) extends Error(cause)
