package java.io

trait Flushable {
  def flush(): Unit
}
