package java.util

trait Set[E] extends Collection[E]
