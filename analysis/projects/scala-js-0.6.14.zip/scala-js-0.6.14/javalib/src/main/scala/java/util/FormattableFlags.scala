package java.util

object FormattableFlags {
  final val ALTERNATE = 4
  final val LEFT_JUSTIFY = 1
  final val UPPERCASE = 2
}
