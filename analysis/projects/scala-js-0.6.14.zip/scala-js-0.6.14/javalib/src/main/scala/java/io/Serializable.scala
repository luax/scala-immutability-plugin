package java.io

trait Serializable
