package java.nio.charset

class CharacterCodingException extends java.io.IOException
