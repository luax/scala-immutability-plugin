package java.util

trait RandomAccess
