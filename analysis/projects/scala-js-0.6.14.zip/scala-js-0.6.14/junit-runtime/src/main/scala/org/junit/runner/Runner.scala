/*
 * Ported from https://github.com/junit-team/junit
 */
package org.junit.runner

abstract class Runner
