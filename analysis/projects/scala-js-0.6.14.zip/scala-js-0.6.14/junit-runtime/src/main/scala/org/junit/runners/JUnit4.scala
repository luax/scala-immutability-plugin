package org.junit.runners

final class JUnit4(klass: Class[_]) extends BlockJUnit4ClassRunner(klass)
