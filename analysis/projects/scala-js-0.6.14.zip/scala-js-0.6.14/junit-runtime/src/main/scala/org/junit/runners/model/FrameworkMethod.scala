package org.junit.runners.model

// Dummy for classOf[...]
class FrameworkMethod
