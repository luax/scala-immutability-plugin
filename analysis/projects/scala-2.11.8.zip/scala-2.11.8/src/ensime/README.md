Ensime project files
=====================

Rename .ensime.SAMPLE to .ensime and replace sample paths with real paths to your sources and build results.
After that you're good to go with one of the ENSIME-enabled text editors.

Editors that know how to talk to ENSIME servers:
1) Emacs via https://github.com/aemoncannon/ensime
2) jEdit via https://github.com/djspiewak/ensime-sidekick
3) TextMate via https://github.com/mads379/ensime.tmbundle
4) Sublime Text 2 via https://github.com/sublimescala/sublime-ensime
