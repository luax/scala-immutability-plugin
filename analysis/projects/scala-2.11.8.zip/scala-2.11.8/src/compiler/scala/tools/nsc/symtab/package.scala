package scala.tools.nsc

package object symtab {

  val Flags = scala.reflect.internal.Flags

}
