package scala.tools.nsc
package transform

trait InlineErasure {
  self: Erasure =>

/*
  import global._
  import definitions._
 */
}
