/**
 * Copyright (C) 2009-2016 Lightbend Inc. <http://www.lightbend.com>
 */
package akka.util

import org.scalatest.junit.JUnitSuiteLike

class JavaDurationSpec extends JavaDuration with JUnitSuiteLike
