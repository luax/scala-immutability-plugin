/**
 * Copyright (C) 2009-2016 Lightbend Inc. <http://www.lightbend.com>
 */
package akka.actor

import org.scalatest.junit.JUnitSuiteLike

class JavaAPISpec extends JavaAPI with JUnitSuiteLike
