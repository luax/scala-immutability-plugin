package akka.japi

import org.scalatest.junit.JUnitSuiteLike

class JavaAPITest extends JavaAPITestBase with JUnitSuiteLike
